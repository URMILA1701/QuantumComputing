# Simon's Algorithm Implementation (Quantum Computing Assignment)

## Secret String
For this implementation of Simon's Algorithm, the chosen 5-bit secret string is:

s = 10110

The goal of the algorithm is to recover this hidden string using a quantum circuit and classical post-processing.

---

## How to Run the Notebook

1. Install required Python packages:

pip install qiskit qiskit-aer numpy sympy matplotlib

2. Open the Jupyter Notebook containing the implementation.

3. Run all cells in order:
   - Part A: Reference Simon Algorithm implementation
   - Part B: Modified implementation for the 5-bit secret string
   - Part C: Classical post-processing to recover the secret string

4. The notebook will:
   - Construct the Simon oracle
   - Execute the quantum circuit using the Qiskit simulator
   - Collect measurement outcomes from the first register
   - Solve the system of equations \(Us = 0 \pmod{2}\)

---

## Recovered Secret String

From the measurement outcomes and solving the linear system \(Us = 0 \pmod{2}\), the recovered secret string is:

s = 01101
Because of bit ordering in Qiskit measurements, the recovered string may appear reversed or equivalent
This matches the hidden string used in the Simon oracle, confirming the correct implementation of Simon's algorithm. 

---

## Files Included

- `Assignment2(A).ipynb` and `Assignment2(A).ipynb` — Implementation of Simon's Algorithm in Qiskit
- `README.md` — Description of the project and instructions to run the notebook